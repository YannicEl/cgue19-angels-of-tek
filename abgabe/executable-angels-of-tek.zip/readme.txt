angels-of-tek

Simon Wesp (11709457)
Yannic Ellhotka (11776168)

tested on Nvida GTX 980, 960M